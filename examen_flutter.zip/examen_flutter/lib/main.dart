import 'package:flutter/material.dart';

void main(){
  runApp(MyApp());
}
class Persona {
  String nombre;
  String apellido;
  int? edad;

  //AQUI TENEMOS UN CONSTRUCTOR POR NOMBRE
  Persona({required this.nombre, required this.apellido});

//AQUI TENEMOS UN CONSTRUCTOR FACTORY PARA ASIGNAR LA EDAD

factory Persona.conEdad({required String nombre, required String apellido, required int edad}) {
  var persona = Persona(nombre: nombre, apellido: apellido);
  persona.edad = edad ;
  return persona;
}

//AQUI TENEMOS UN METODO TOSTRING PARA DEVOLVER LOS NOMBRE Y LA EDAD
@override
  String toString(){
  return '$nombre $apellido - Edad: $edad';
}
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    //AQUI TENEMOS LA INSTANCIA  DE PERSONA
    Persona estudiante = Persona.conEdad(nombre: 'angela', apellido: 'campoverde', edad: 21);
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Estudiantes'),
        ),
        body: Center(
        child: Container(
          color: Colors.white,
            child: Text(
              estudiante.toString(),
              style: TextStyle(
                color: Colors.blue,
                fontSize: 20.0,
              ),
              textAlign: TextAlign.center,
            ),
        ),
        ),
      ),
    );
  }
}

